package com.swc.onestop.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.ramotion.garlandview.TailLayoutManager;
import com.ramotion.garlandview.TailRecyclerView;
import com.ramotion.garlandview.TailSnapHelper;
import com.ramotion.garlandview.header.HeaderTransformer;
import com.swc.onestop.Activities.Freshers.Details.DetailsActivity;
import com.swc.onestop.Activities.Freshers.GarlandApp;
import com.swc.onestop.Activities.Freshers.inner.InnerData;
import com.swc.onestop.Activities.Freshers.inner.InnerItem;
import com.swc.onestop.Activities.Freshers.outer.OuterAdapter;
import com.swc.onestop.Activities.Freshers.profile.ProfileActivity;
import com.swc.onestop.MainActivity_Models.CustomAdapter;
import com.swc.onestop.MainActivity_Models.Data_model;
import com.swc.onestop.R;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.bloco.faker.Faker;
import io.reactivex.Single;
import io.reactivex.SingleEmitter;
import io.reactivex.SingleOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class FreshersActivity extends AppCompatActivity implements GarlandApp.FakerReadyListener {

    int OUTER_COUNT =2 ;
    int INNER_COUNT =1;
    final List<List<InnerData>> outerData_Firebase = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_freshers);
        ((GarlandApp)getApplication()).addListener(this);

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // back button pressed
                startActivity(new Intent(FreshersActivity.this, Main2Activity.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION));
                finish();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onFakerReady(final Faker faker) {


        FirebaseFirestore rootRef = FirebaseFirestore.getInstance();
        final CollectionReference freshRef = rootRef.collection("Freshers");
        freshRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    OUTER_COUNT++;
                    for (final DocumentSnapshot outerDocument : task.getResult()) {
                        final List<InnerData> innerData_Firebase = new ArrayList<>();

                        freshRef.document(outerDocument.getId()).collection("SubPosts").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if (task.isSuccessful()) {

                                    for (DocumentSnapshot innerDocument : task.getResult()) {
                                        Map singleData = innerDocument.getData();
                                        Toast.makeText(FreshersActivity.this, "InnerData", Toast.LENGTH_SHORT).show();
                                        innerData_Firebase.add(new InnerData(singleData.get("title").toString(),
                                                singleData.get("name").toString(),
                                                singleData.get("address").toString(),
                                                singleData.get("imageUrl").toString(),
                                                Integer.valueOf(singleData.get("age").toString()),
                                                innerDocument.getId(),
                                                outerDocument.getId()));
                                        INNER_COUNT++;
                                        Log.i("DATA_COUNT_INNER",INNER_COUNT + " " +OUTER_COUNT );
                                        Log.d("Inner_Firebase",innerData_Firebase.toString());

                                    }
                                } else {
                                    Log.d("InnerData", "error");
                                }
                                Log.i("DATA_COUNT_OUTTER",INNER_COUNT + " " +OUTER_COUNT );
                                outerData_Firebase.add(innerData_Firebase);
                                Log.d("Outter_Firebase",outerData_Firebase.toString());
                                Single.create(new SingleOnSubscribe<List<List<InnerData>>>() {
                                    @Override
                                    public void subscribe(SingleEmitter<List<List<InnerData>>> e) throws Exception {
                                        final List<List<InnerData>> outerData = new ArrayList<>();
                                        for (int i = 0; i < OUTER_COUNT && !e.isDisposed(); i++) {
                                            final List<InnerData> innerData = new ArrayList<>();
                                            for (int j = 0; j < INNER_COUNT && !e.isDisposed(); j++) {
                                             //   innerData.add(createInnerData(faker));
                                              //  Log.d("InnerData",innerData.toString());
                                            }
                                         //   outerData.add(innerData);
                                        //    Log.d("OutterData",outerData.toString());


                                        }

                                        if (!e.isDisposed()) {
                                           e.onSuccess(outerData_Firebase);
                                        }
                                    }
                                })
                                        .subscribeOn(Schedulers.io())
                                        .observeOn(AndroidSchedulers.mainThread())
                                        .subscribe(new Consumer<List<List<InnerData>>>() {
                                            @Override
                                            public void accept(List<List<InnerData>> outerData) throws Exception {
                                                initRecyclerView(outerData_Firebase);
                                            }
                                        });
                                initRecyclerView(outerData_Firebase);
                            }
                        });
                    }
                    Toast.makeText(FreshersActivity.this, "Done "+ OUTER_COUNT + "  " +INNER_COUNT , Toast.LENGTH_SHORT).show();
                    Log.d("Firebase_data",outerData_Firebase.toString());

                } else {
                    Log.d("test", "error");
                }

                initRecyclerView(outerData_Firebase);



            }
        });


    }

    private void initRecyclerView(List<List<InnerData>> data) {
        findViewById(R.id.progressBar).setVisibility(View.GONE);

        final TailRecyclerView rv = (TailRecyclerView) findViewById(R.id.recycler_view);
        ((TailLayoutManager)rv.getLayoutManager()).setPageTransformer(new HeaderTransformer());
        rv.setOnFlingListener(null);
        rv.setAdapter(new OuterAdapter(data));

        new TailSnapHelper().attachToRecyclerView(rv);
    }

    private InnerData createInnerData(Faker faker) {

        Log.i("Data", "Title :"+ faker.book.title() );
        Log.i("Data", "Name :"+ faker.name.name() );
        Log.i("Data", "Address :"+ faker.address.city() + ", " + faker.address.stateAbbr() );
        Log.i("Data", "Email :"+ faker.internet.email() );
        Log.i("Data", "AGE :"+ faker.number.between(20, 50) );

//        return new InnerData(
//                faker.book.title(),
//                faker.name.name(),
//                faker.address.city() + ", " + faker.address.stateAbbr(),
//                faker.avatar.image(faker.internet.email(), "150x150", "jpg", "set1", "bg1"),
//                faker.number.between(20, 50)
//        );
//        return new InnerData(outerData_Firebase.get(i).get(j).title
//               ,"a"
//               outerData_Firebase.get(i).get(j).name,"b",
//                outerData_Firebase.get(i).get(j).address,"c",
//                outerData_Firebase.get(i).get(j).avatarUrl,"d",
//               outerData_Firebase.get(i).get(j).age"e"
//        );
        return new InnerData("a","b","c","d",12,"test","test");



    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        // startActivity(new Intent(ProfileActivity.this, FreshersActivity.class));
        finish();
    }
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void OnInnerItemClick(InnerItem item) {
        final InnerData itemData = item.getItemData();
        if (itemData == null) {
            return;
        }

        DetailsActivity.start(this,
                item.getItemData().title, item.mName.getText().toString(),
                item.getItemData().avatarUrl, item.itemView, item.mAvatarBorder,item.getItemData().innerID,item.getItemData().outerID);
    }

}


