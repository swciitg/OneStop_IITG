package com.swc.onestop.MainActivity_Models;

public class MyData {



    public static String[] titleArray = {"Students Web Commitee","Cultural Secretary", "Cultural Secretary", "Sports Secretary", "Technical Secretary", "Sports Secretary"};
    public static String[] subtitleArray = {"Announcement", "Event", "Event", "Event", "Event", "Announcement"};
    public static String[] descArray = {"Indian Institute of Technology Guwahati, the sixth member of the IIT fraternity, was established in 1994. The academic programme of IIT Guwahati commenced in 1995. At present the Institute has eleven departments and five inter-disciplinary academic centres covering all the major engineering, science and humanities disciplines, offering BTech, BDes, MA, MDes, MTech, MSc and PhD programmes. Within a short period of time, IIT Guwahati has been able",
            "Indian Institute of Technology Guwahati, the sixth member of the IIT fraternity, was established in 1994. The academic programme of IIT Guwahati commenced in 1995. At present the Institute has eleven departments and five inter-disciplinary academic centres covering all the major engineering, science and humanities disciplines, offering BTech, BDes, MA, MDes, MTech, MSc and PhD programmes. Within a short period of time, IIT Guwahati has been able","Indian Institute of Technology Guwahati, the sixth member of the IIT fraternity, was established in 1994. The academic programme of IIT Guwahati commenced in 1995. At present the Institute has eleven departments and five inter-disciplinary academic centres covering all the major engineering, science and humanities disciplines, offering BTech, BDes, MA, MDes, MTech, MSc and PhD programmes. Within a short period of time, IIT Guwahati has been able", "Indian Institute of Technology Guwahati, the sixth member of the IIT fraternity, was established in 1994.",
    "Indian Institute of Technology Guwahati, the sixth member of the IIT fraternity, was established in 1994.","Indian Institute of Technology Guwahati, the sixth member of the IIT fraternity, was established in 1994."};

    public static String[] dpArray = {"https://image.shutterstock.com/image-photo/studio-shot-young-man-looking-260nw-372072697.jpg","https://image.shutterstock.com/image-photo/studio-shot-young-man-looking-260nw-372072697.jpg",
    "https://image.shutterstock.com/image-photo/studio-shot-young-man-looking-260nw-372072697.jpg","http://transcosmos.co.uk/wp-content/uploads/2015/09/google_logo_03-818x600.jpg",
    "http://transcosmos.co.uk/wp-content/uploads/2015/09/google_logo_03-818x600.jpg","http://transcosmos.co.uk/wp-content/uploads/2015/09/google_logo_03-818x600.jpg"};

    public static String[] imageArray = {"","","","","",""};
}