package com.swc.onestop.Activities;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;

import com.google.android.material.snackbar.Snackbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.content.Intent;


import com.joanzapata.pdfview.PDFView;
import com.joanzapata.pdfview.listener.OnLoadCompleteListener;
import com.joanzapata.pdfview.listener.OnPageChangeListener;
import com.swc.onestop.MyDownloadManager;
import com.swc.onestop.R;

import java.io.File;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class Timetable extends AppCompatActivity implements OnLoadCompleteListener, OnPageChangeListener {

    ProgressDialog progressdialog;
    PDFView pdfview;
    String dir =Environment.getExternalStorageDirectory().toString()+"/OneStop/";
    String timetableurl = "https://firebasestorage.googleapis.com/v0/b/onestopiitg.appspot.com/o/Timetable?alt=media&token=e9281626-2b0d-40ce-8bfc-3563c5f65a35";
    private static final int PERMISSION_REQUEST_CODE = 200;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timetable);
        pdfview = (PDFView) findViewById(R.id.pdf);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // back button pressed
                startActivity(new Intent(Timetable.this,Main2Activity.class));
            }
        });

        progressdialog = new ProgressDialog(Timetable.this);
        progressdialog.setMessage("Timetable Downloading....");
        if(checkPermission())
            LoadPDF(timetableurl);
        else
            requestPermission();

    }


    public void LoadPDF(String url){
        if(isExternalStorageReadable() && isExternalStorageWritable()){

            File file = new File(dir, "/"+"Timetable.pdf");

            // Log.i("shivam",dir+"/"+ Hostel + ".pdf");
            // Log.i("Testing",getFilesDir().toString());
            if (!file.exists()){
                Log.i("shivam","File Does not exists");

                if (isOnline()) {
                    beginDownload("Timetable",url);
                    progressdialog.show();
                }

                else{
                    showSnackbar();
                }


            }
            else {
                SetPDF("Timetable");
                Log.i("shivam","File exists");

            }





        }
    }


    private void beginDownload(final String Hostel, String URL) {


        BroadcastReceiver listener = new BroadcastReceiver() {
            @Override
            public void onReceive( Context context, Intent intent ) {
                //String data = intent.getStringExtra("Download complete");
                Log.i("shivam",Hostel+" File Downloading at"+dir);
                progressdialog.hide();
                SetPDF(Hostel);
            }
        };

        LocalBroadcastManager.getInstance(this).registerReceiver(listener,
                new IntentFilter("Download complete"));

        MyDownloadManager downloadManager = new MyDownloadManager();

        downloadManager.Download(getApplicationContext(),"Timetable", URL);





    }
    public void SetPDF(String Hostel){
        Log.e("test","PDF Loaded");
        File file = new File(dir+"/"+Hostel + ".pdf");

        if(file.exists()) {
            pdfview.fromFile(file)
                    .defaultPage(1)
                    .showMinimap(false)
                    .enableSwipe(true)
                    .onLoad(Timetable.this)
                    .onPageChange(Timetable.this)
                    .load();
        }
        else {
            if (isOnline()) {
                beginDownload("Timetable",timetableurl);
                progressdialog.show();
            }

            else{
                showSnackbar();
            }
        }


    }
    /* Checks if external storage is available for read and write */
    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }

    /* Checks if external storage is available to at least read */
    public boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }


    public boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            Log.i("Internet" ,"Online");
            return true;
        }
        Log.i("Internet" ,"Offline");
        return false;
    }

    public void showSnackbar(){
        final Snackbar snackbar = Snackbar
                .make((LinearLayout)findViewById(R.id.remote_pdf_root), "You are Offline", Snackbar.LENGTH_LONG)
                .setAction("Retry", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (isOnline()){
                                LoadPDF(timetableurl);
                        }
                        else
                            showSnackbar();
                    }
                });
        snackbar.show();

    }

    @Override
    public void loadComplete(int nbPages) {

    }

    @Override
    public void onPageChanged(int page, int pageCount) {

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(Timetable.this, Main2Activity.class).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(i);
        finish();
    }



    private boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(), ACCESS_FINE_LOCATION);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), READ_EXTERNAL_STORAGE);
        int result2 = ContextCompat.checkSelfPermission(getApplicationContext(), WRITE_EXTERNAL_STORAGE);

        return result == PackageManager.PERMISSION_GRANTED && result1 == PackageManager.PERMISSION_GRANTED &&result2 == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {

        ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION, READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0) {

                    boolean locationAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean readAccepted = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    boolean writeAccepted = grantResults[2] == PackageManager.PERMISSION_GRANTED;

                    if (locationAccepted && readAccepted && writeAccepted){

                        LoadPDF(timetableurl);
                        // Snackbar.make(view, "Permission Granted, Now you can access location data and camera.", Snackbar.LENGTH_LONG).show();
                    }

                    else {

                        //Snackbar.make(view, "Permission Denied, You cannot access location data and camera.", Snackbar.LENGTH_LONG).show();

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            if (shouldShowRequestPermissionRationale(ACCESS_FINE_LOCATION)) {
                                showMessageOKCancel("You need to allow access to both the permissions",
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                    requestPermissions(new String[]{ACCESS_FINE_LOCATION, WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE},
                                                            PERMISSION_REQUEST_CODE);
                                                }
                                            }
                                        });
                                return;
                            }
                        }

                    }
                }


                break;
        }
    }
    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new AlertDialog.Builder(Timetable.this)
                .setMessage(message)
                .setPositiveButton("Allow", okListener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

}
