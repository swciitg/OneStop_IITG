package com.swc.onestop.Activities.Freshers.Details;

import androidx.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.ViewGroup;


import com.swc.onestop.R;
import com.swc.onestop.databinding.DetailsItemBinding;

import java.util.List;

import androidx.recyclerview.widget.RecyclerView;


public class DetailsAdapter extends RecyclerView.Adapter<DetailsItem> {

    List<DetailsData> mData;

   public DetailsAdapter(List<DetailsData> data) {
        super();
        mData = data;
    }

    @Override
    public DetailsItem onCreateViewHolder(ViewGroup parent, int viewType) {
        final LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        final DetailsItemBinding binding = DataBindingUtil.inflate(inflater, R.layout.details_item, parent, false);
        return new DetailsItem(binding.getRoot());
    }

    @Override
    public void onBindViewHolder(DetailsItem holder, int position) {
        holder.setContent(mData.get(position));
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

}
