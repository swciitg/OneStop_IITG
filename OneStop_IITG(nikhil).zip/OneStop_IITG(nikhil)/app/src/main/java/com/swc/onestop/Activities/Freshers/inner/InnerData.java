package com.swc.onestop.Activities.Freshers.inner;

public class InnerData {

    public final String title;
    public final String name;
    public final String address;
    public final String avatarUrl;
    public final int age;

    public final String innerID;
    public final String outerID;

    public InnerData(String title, String name, String address, String avatarUrl, int age,String innerID,String outerID) {
        this.title = title;
        this.name = name;
        this.address = address;
        this.avatarUrl = avatarUrl;
        this.age = age;
        this.innerID=innerID;
        this.outerID=outerID;
    }
}
